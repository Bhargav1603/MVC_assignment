// src/main/java/com/example/demo/DemoApplication.java
package com.example.RestApiTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiTest {
	public static void main(String[] args) {
		SpringApplication.run(RestApiTest.class, args);
	}
}
